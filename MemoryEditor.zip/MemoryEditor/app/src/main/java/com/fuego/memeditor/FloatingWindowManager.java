//Credits :- @ALLAN_FUEGO
package com.fuego.memeditor;

// FloatingWindowManager.java
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.ImageButton;
import java.io.IOException;
import android.content.res.AssetManager;
import java.io.InputStream;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import java.util.List;
import java.util.ArrayList;
import android.widget.ToggleButton;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Button;
import android.graphics.LinearGradient;
import android.text.method.ScrollingMovementMethod;
import android.view.GestureDetector;
import android.widget.Toast;

public class FloatingWindowManager
    {
        public static native void Changes(int feature, boolean isChecked);
        public static native String[] getFeatures();
        private String Credits = "FUEGO MODS";
        private static FloatingWindowManager instance;
        private static Context context;
        private WindowManager windowManager;
        private LinearLayout floatingView;
        private ScrollView scrollView;
        private LinearLayout childScroll;
        private ImageButton floatingIcon;
        private WindowManager.LayoutParams params;


        public FloatingWindowManager ( Context context )
            {
                this.context = context;
                windowManager = (WindowManager) context.getSystemService ( Context.WINDOW_SERVICE );
                createFloatingView ( );
                createFloatingIcon ( );

            }

        public static FloatingWindowManager getInstance ( Context context )
            {
                if ( instance == null )
                    {
                        instance = new FloatingWindowManager ( context.getApplicationContext ( ) );
                    }
                return instance;
            }


        private void createFloatingView ( )
            {
                params = new WindowManager.LayoutParams (
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                    WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT );

                params.gravity = Gravity.TOP | Gravity.START;
                params.x = 0;
                params.y = 100;

                // Create a simple TextView as the content of the floating window
                TextView textView = new TextView ( context );
                textView.setText ( Credits );
                textView.setBackgroundColor ( Color.BLUE );
                textView.setTextColor ( Color.WHITE );
                textView.setGravity ( Gravity.CENTER );

                Button CloseWindow = new Button ( context );
                CloseWindow.setText ( "HIDE MENU" );
                CloseWindow.setBackgroundColor ( Color.BLACK );
                CloseWindow.setTextColor ( Color.WHITE );
                CloseWindow.setPaddingRelative(0,10,0,0);
                CloseWindow.setOnClickListener ( new View.OnClickListener ( ) {

                            @Override
                            public void onClick ( View view )
                                {
                                    removeFloatingWindow ( );
                                    removeFloatingIcon ( );
                                }
						} );

                scrollView = new ScrollView ( context );
                scrollView.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                320
                ));
                childScroll = new LinearLayout ( context );
                childScroll.setLayoutParams ( new LinearLayout.LayoutParams (
                                                 LinearLayout.LayoutParams.MATCH_PARENT,
                                                 300
                                             ) );
                childScroll.setOrientation ( LinearLayout.VERTICAL );

                floatingView = new LinearLayout ( context );
                floatingView.setOrientation ( LinearLayout.VERTICAL );
                LinearLayout.LayoutParams LParams = new LinearLayout.LayoutParams (
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                );
                floatingView.setLayoutParams ( LParams );
                floatingView.addView ( textView );
                floatingView.addView ( scrollView );
                scrollView.addView ( childScroll , -1, -1 );
                floatingView.addView ( CloseWindow );

                // Set touch listener to make the floating window moveable
                floatingView.setOnTouchListener ( new View.OnTouchListener ( ) {
                            private int initialX;
                            private int initialY;
                            private float initialTouchX;
                            private float initialTouchY;

                            @Override
                            public boolean onTouch ( View v, MotionEvent event )
                                {
                                    switch ( event.getAction ( ) )
                                        {
                                            case MotionEvent.ACTION_DOWN:
                                                initialX = params.x;
                                                initialY = params.y;
                                                initialTouchX = event.getRawX ( );
                                                initialTouchY = event.getRawY ( );
                                                return true;
                                            case MotionEvent.ACTION_MOVE:
                                                params.x = initialX + (int) ( event.getRawX ( ) - initialTouchX );
                                                params.y = initialY + (int) ( event.getRawY ( ) - initialTouchY );
                                                windowManager.updateViewLayout ( floatingView, params );
                                                return true;
                                        }
                                    return false;
                                }
                        } );

                windowManager.addView ( floatingView, params );
            }

        private void createFloatingIcon ( )
            {
                floatingIcon = new ImageButton ( context );
                loadIconFromAssets ( "icon.png", floatingIcon );
                floatingIcon.setBackgroundColor ( Color.TRANSPARENT );
                floatingIcon.setScaleType ( ImageButton.ScaleType.FIT_CENTER );

                final WindowManager.LayoutParams iconParams = new WindowManager.LayoutParams (
                    200,
                    200,
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                    WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT );

                iconParams.gravity = Gravity.TOP | Gravity.START;
                iconParams.x = 500;  // Adjust the initial position as needed
                iconParams.y = 100;

                if ( floatingIcon != null )
                    {

                        final GestureDetector gestureDetector = new GestureDetector ( context, new GestureDetector.SimpleOnGestureListener ( ) {
                                    @Override
                                    public boolean onSingleTapUp ( MotionEvent e )
                                        {
                                            handleClick ( false );
                                            return true;
                                        }

                                    @Override
                                    public void onLongPress ( MotionEvent e )
                                        {
                                            handleClick ( true );
                                        }
                                } );

                        final float[] touchX = {0};
                        final float[] touchY = {0};
                        floatingIcon.setOnTouchListener ( new View.OnTouchListener ( ) {
                                    private int initialX;
                                    private int initialY;
                                    private float initialTouchX;
                                    private float initialTouchY;

                                    @Override
                                    public boolean onTouch ( View v, MotionEvent event )
                                        {
                                            gestureDetector.onTouchEvent ( event );
                                            switch ( event.getAction ( ) )
                                                {
                                                    case MotionEvent.ACTION_DOWN:
                                                        initialX = iconParams.x;
                                                        initialY = iconParams.y;
                                                        initialTouchX = event.getRawX ( );
                                                        initialTouchY = event.getRawY ( );
                                                        touchX [ 0 ] = event.getRawX ( );
                                                        touchY [ 0 ] = event.getRawY ( );
                                                        return true;
                                                    case MotionEvent.ACTION_MOVE:
                                                        iconParams.x = initialX + (int) ( event.getRawX ( ) - initialTouchX );
                                                        iconParams.y = initialY + (int) ( event.getRawY ( ) - initialTouchY );
                                                        windowManager.updateViewLayout ( floatingIcon, iconParams );
                                                        touchX [ 0 ] = event.getRawX ( );
                                                        touchY [ 0 ] = event.getRawY ( );
                                                        return true;
                                                    case MotionEvent.ACTION_UP:
                                                        float distance = Math.abs ( event.getRawX ( ) - touchX [ 0 ] ) +
                                                            Math.abs ( event.getRawY ( ) - touchY [ 0 ] );
                                                        if ( distance >= 10 )
                                                            {
                                                                // Icon was dragged, handle the drag
                                                                handleClick ( true );
                                                            }
                                                        return true;
                                                }
                                            return false;
                                        }
                                } );
                    }
                windowManager.addView ( floatingIcon, iconParams );
            }

        private void handleClick ( boolean wasDrag )
            {
                if ( !wasDrag )
                    {
                        // Handle the click event here
                        if ( floatingView.getVisibility ( ) == View.VISIBLE )
                            {
                                hideFloatingWindow ( );
                            }
                        else
                            {
                                showFloatingWindow ( );
                            }
                    }
            }
            
        public void AddButtons(){
            String[] feature = getFeatures();
            
            for(String fullString : feature){
                    final String[] split = fullString.split("_");
                    
                    switch(split[1]){
                            case "ToggleButton":
                                ToggleButton toggle = new ToggleButton(context);
                                toggle.setTextOn(split[2] + " : ON");
                                toggle.setTextOff(split[2] + " : OFF");
                                toggle.setChecked(false);
                                toggle.setTextColor(Color.BLACK);
                                
                                childScroll.addView(toggle);
                                
                                toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener () {
                                    @Override
                                    public void onCheckedChanged(CompoundButton btn, boolean isChecked){
                                        Changes(Integer.parseInt(split[0]), isChecked);
                                    }
                                });
                            break;
                    }
            }
        }
        
//        public void AddToggle ( String Name, final Runnable onCheck, final Runnable onUnCheck )
//            {
//                ToggleButton toggle = new ToggleButton ( context );
//                toggle.setTextOn ( Name + " : ON" );
//                toggle.setTextOff ( Name + " : OFF" );
//                toggle.setChecked ( false );
//                toggle.setTextColor ( Color.BLACK );
//
//
//                childScroll.addView ( toggle );
//
//                toggle.setOnCheckedChangeListener ( new CompoundButton.OnCheckedChangeListener ( ){
//                            @Override
//                            public void onCheckedChanged ( CompoundButton buttonView, boolean isChecked )
//                                {
//                                    // Handle toggle state change directly
//                                    if ( isChecked )
//                                        {
//                                            // Execute logic when toggle is turned on
//                                            if ( onCheck != null )
//                                                {
//                                                    onCheck.run ( );
//                                                }
//                                        }
//                                    else
//                                        {
//                                            // Execute logic when toggle is turned off
//                                            if ( onUnCheck != null )
//                                                {
//                                                    onUnCheck.run ( );
//                                                }
//                                        }
//                                }
//                        } );
//            }

        private void loadIconFromAssets ( String fileName, ImageButton imageButton )
            {
                try
                    {
                        AssetManager assetManager = context.getAssets ( );
                        InputStream inputStream = assetManager.open ( fileName );
                        Bitmap bitmap = BitmapFactory.decodeStream ( inputStream );
                        imageButton.setImageBitmap ( bitmap );
                    }
                catch (IOException e)
                    {
                        e.printStackTrace ( );
                    }
            }

        public void showFloatingIcon ( )
            {
                if ( floatingView != null )
                    {
                        floatingView.setVisibility ( View.VISIBLE );
                    }
            }

        public void hideFloatingIcon ( )
            {
                if ( floatingView != null )
                    {
                        floatingView.setVisibility ( View.GONE );
                    }
            }

        public void removeFloatingIcon ( )
            {
                if ( floatingView != null )
                    {
                        windowManager.removeView ( floatingIcon );
                    }
            }

        public void showFloatingWindow ( )
            {
                if ( floatingView != null )
                    {
                        floatingView.setVisibility ( View.VISIBLE );
                    }
            }

        public void hideFloatingWindow ( )
            {
                if ( floatingView != null )
                    {
                        floatingView.setVisibility ( View.GONE );
                    }
            }

        public void removeFloatingWindow ( )
            {
                if ( floatingView != null )
                    {
                        windowManager.removeView ( floatingView );
                    }
            }
    }

