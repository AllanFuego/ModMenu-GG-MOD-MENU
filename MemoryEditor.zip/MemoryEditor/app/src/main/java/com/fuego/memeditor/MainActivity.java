//Credits :- @ALLAN_FUEGO
package com.fuego.memeditor;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.net.Uri;
import android.view.MotionEvent;
import android.widget.Toast;

public class MainActivity extends Activity
    {
        private static FloatingWindowManager FloatingManager;
        @Override
        protected void onCreate ( Bundle p1 )
            {
                super.onCreate ( p1 );

                Start ( this );
            }

        public static void Start ( final Context ctx )
            {
                System.loadLibrary("FuegoMods");
                
                if ( Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays ( ctx ) )
                    {
                        Intent intent = new Intent ( Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                                    Uri.parse ( "package:" + ctx.getPackageName ( ) ) );
                        ctx.startActivity ( intent );

                    }
                FloatingManager = FloatingWindowManager.getInstance ( ctx );
                FloatingManager.AddButtons();
                FloatingManager.hideFloatingWindow ( );
                FloatingManager.showFloatingIcon ( );
            }

        @Override
        protected void onDestroy ( )
            {
                super.onDestroy ( );
                FloatingManager.removeFloatingWindow ( );
                FloatingManager.removeFloatingIcon ( );
            }

    }

