//Credits :- @ALLAN_FUEGO

#include <iostream>
#include <jni.h>
#include <thread>
#include <pthread.h>
#include "JNI-FUEGO/Thread.h"
#include "MemoryTool/include/MemoryTool.h"

MemoryScanner md;
bool NormalEdit = false,OffEdit = false;

extern "C"{
JNIEXPORT jobjectArray  JNICALL Java_com_fuego_memeditor_FloatingWindowManager_getFeatures(JNIEnv *env, jobject activityObject) {
    jobjectArray ret;
        
        const char* features[]={
            "0_ToggleButton_BigHit On",
            "1_ToggleButton_BigHit Off",
        };
        int Total_Feature = (sizeof features /
                         sizeof features[0]); //Now you dont have to manually update the number everytime;
    
    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"), env->NewStringUTF(""));
    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    return (ret);
}

void BigHitOn(){
    md.MemorySearch("1058642330",DWORD,OTHER);
    md.MemoryOffset("0",DWORD,-60);
    md.MemoryOffset("0",DWORD,-56);
    md.MemoryOffset("0",DWORD,-32);
    md.MemoryOffset("0",DWORD,-28);
    md.MemoryEdit("1086324736",DWORD,0);
    md.MemoryClear();
}

void BigHitOf(){
    md.MemorySearch("1086324736",DWORD,OTHER);
    md.MemoryOffset("0",DWORD,-60);
    md.MemoryOffset("0",DWORD,-56);
    md.MemoryOffset("0",DWORD,-32);
    md.MemoryOffset("0",DWORD,-28);
    md.MemoryEdit("1058642330",DWORD,0);
    md.MemoryClear();
}

JNIEXPORT void JNICALL
Java_com_fuego_memeditor_FloatingWindowManager_Changes(JNIEnv *env,jobject obj,jint feature,jboolean boolean) {
    /*  FEATURES  */
    
    switch (feature) {
            case 0:
                NormalEdit = boolean;
                if(NormalEdit){
                    Run(BigHitOn);
                  }
            break;
            
            case 1:
                OffEdit = boolean;
                if(OffEdit){
                    Run(BigHitOf);
                }
             break;
                
                
    }
}

}
