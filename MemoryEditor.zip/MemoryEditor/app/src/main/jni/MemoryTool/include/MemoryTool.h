#pragma once
//Credits :- @ALLAN_FUEGO
enum Region{
	ALL, 
	B_BAD,
	V,	
	C_ALLOC,    
	C_BSS,   
	C_DATA,    
	C_HEAP,   
	JAVA_HEAP, 
	A_ANONMYOUS,
	CODE_SYSTEM,
	STACK,   
	ASHMEM,   
	CODE_APP,
	OTHER
};

enum Type{
	DWORD,
	FLOAT,
	QWORD,
	WORD
};

class MemoryScanner{
	public:
	
	void MemorySearch(char *value,Type type, Region region);
	
	void MemoryOffset(char *num, Type type, int offset);
	
	void MemoryEdit(char *num, Type type, int offset);
	
	void MemoryFreeze(char *num, Type type, int offset);
	
	int GetResultsCount();
	
	void MemoryClear();
};
