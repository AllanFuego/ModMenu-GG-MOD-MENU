// ToastUtil.cpp

#include "jni.h"
#include <android/log.h>
