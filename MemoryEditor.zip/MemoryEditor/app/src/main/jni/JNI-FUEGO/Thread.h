//Credits :- @ALLAN_FUEGO
#ifndef THREAD_H
#define THREAD_H

void Run(std::function<void()> func){
    std::thread(func).detach();
}

#endif
