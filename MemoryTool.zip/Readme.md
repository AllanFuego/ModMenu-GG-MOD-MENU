Add In Android.mk

include $(CLEAR_VARS)
LOCAL_MODULE := MemoryFuego
LOCAL_SRC_FILES := MemoryTool/lib/libMemoryTool.a
LOCAL_EXPORT_C_INCLUDES := $(LOCAL_PATH)/MemoryTool/include
include $(PREBUILT_STATIC_LIBRARY)

Before $(BUILT_SHARED_LIBRARY)
LOCAL_STATIC_LIBRARIES := MemoryFuego

In main.cpp
#include "MemmoryTool/include/MemoryTool.h"

MemoryScanner md;
md.MemorySearch("value",Type,Region);
md.MemoryOffset("value",Type,offset);
md.MemoryEdit("value",Type,offset);
md.MemoryClear();


In Application.mk
APP_ABI := armeabi-v7a
#APP_ABI := arm64-v8a
APP_PLATFORM := android-23
APP_STL := c++_static
APP_OPTIM := release
APP_CPPFLAGS := -std=c++14 -fno-rtti -fno-exceptions -DNDEBUG -Wall -fpermissive -fpic
APP_LDFLAGS := -llog
APP_THIN_ARCHIVE := true
APP_PIE         := true

->APP_PLATFORM MUST BE android-20 +